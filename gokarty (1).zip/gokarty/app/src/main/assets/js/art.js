'use strict';
// Cala grafika jest rysowana w kodzie - bez zewnetrznych plikow.
const Art = (() => {
  function make(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h); return c;
  }
  const ell = (g, x, y, rx, ry, col, rot = 0) => { g.fillStyle = col; g.beginPath(); g.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2); g.fill(); };
  const box = (g, x, y, w, h, r, col) => {
    g.fillStyle = col; g.beginPath(); g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.fill();
  };
  const poly = (g, col, pts) => {
    g.fillStyle = col; g.beginPath(); g.moveTo(pts[0], pts[1]);
    for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]);
    g.closePath(); g.fill();
  };

  const RAINBOW = ['#ff4757', '#ff9f1a', '#ffe32e', '#2ed573', '#1e90ff', '#a55eea'];

  // Styl "naklejki": ciemny kontur, polysk od gory i cien od dolu.
  function polish(src, line = 3, shadow = false) {
    const w = src.width, h = src.height;
    const lit = make(w, h, g => {
      g.drawImage(src, 0, 0); g.globalCompositeOperation = 'source-atop';
      const gr = g.createLinearGradient(0, 0, w * 0.35, h);
      gr.addColorStop(0, 'rgba(255,255,255,.32)'); gr.addColorStop(0.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(20,0,50,.28)');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
    const sil = make(w, h, g => { g.drawImage(src, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = '#1b1030'; g.fillRect(0, 0, w, h); });
    return make(w, h, g => {
      if (shadow) ell(g, w / 2, h * 0.93, w * 0.46, h * 0.06, 'rgba(0,0,0,.28)');
      for (let i = 0; i < 12; i++) g.drawImage(sil, Math.cos(i * Math.PI / 6) * line, Math.sin(i * Math.PI / 6) * line);
      g.drawImage(lit, 0, 0);
    });
  }
  // obiekt z marginesem na kontur, rysowany w wyzszej rozdzielczosci
  const sticker = (c, line = 3) => polish(make(c.width + 12, c.height + 6, g => g.drawImage(c, 6, 6)), line);

  function balloons() {
    return RAINBOW.map((_, f) => polish(make(120, 180, g => {
      g.strokeStyle = '#fff'; g.lineWidth = 3; g.beginPath(); g.moveTo(60, 125); g.bezierCurveTo(40, 142, 82, 155, 58, 176); g.stroke();
      g.save(); g.beginPath(); g.ellipse(60, 66, 50, 60, 0, 0, 7); g.clip();
      for (let i = 0; i < 6; i++) { g.fillStyle = RAINBOW[(i + f) % 6]; g.fillRect(0, 6 + i * 20, 120, 21); }
      g.restore();
      poly(g, RAINBOW[(f + 5) % 6], [60, 120, 73, 138, 47, 138]);
      ell(g, 40, 40, 12, 20, 'rgba(255,255,255,.75)', 0.6);
      const s = f % 2 ? [98, 22] : [20, 104];
      poly(g, '#fff', [s[0], s[1] - 17, s[0] + 4, s[1] - 4, s[0] + 17, s[1], s[0] + 4, s[1] + 4, s[0], s[1] + 17, s[0] - 4, s[1] + 4, s[0] - 17, s[1], s[0] - 4, s[1] - 4]);
    }), 4));
  }
  const cloud = tint => make(240, 108, g => { [[60, 70, 48, 30], [115, 50, 55, 42], [175, 68, 50, 32], [120, 76, 100, 26]].forEach(c => ell(g, c[0], c[1], c[2], c[3], tint)); });

  /* ---------- Gokarty i kierowcy ---------- */
  const KARTS = [
    { name: 'Misio', animal: 'bear', body: '#e74c3c', dark: '#922b21', trim: '#ffd32a' },
    { name: 'Piesek', animal: 'dog', body: '#2e86de', dark: '#1b4f72', trim: '#ffffff' },
    { name: 'Króliczek', animal: 'bunny', body: '#e84393', dark: '#8e2459', trim: '#7bed9f' }
  ];

  function head(g, animal, x, y, front) {
    if (animal === 'bear') {
      [-1, 1].forEach(s => { ell(g, x + s * 31, y - 28, 17, 17, '#8d5a32'); ell(g, x + s * 31, y - 28, 8, 8, '#d9a066'); });
      ell(g, x, y, 42, 38, '#8d5a32');
      if (front) ell(g, x, y + 13, 20, 15, '#e5bd8b');
    } else if (animal === 'dog') {
      ell(g, x, y, 38, 37, '#e8c48f');
      [-1, 1].forEach(s => ell(g, x + s * 40, y + 2, 14, 31, '#7b4a24', -s * 0.35));
      if (front) { ell(g, x + 14, y - 8, 14, 15, '#b57a45'); ell(g, x, y + 14, 19, 14, '#fff3df'); ell(g, x + 3, y + 28, 6, 9, '#ff6b81'); }
      else ell(g, x, y - 22, 17, 11, '#b57a45');
    } else {
      [-1, 1].forEach(s => { ell(g, x + s * 18, y - 49, 12, 35, '#f1f2f6', s * 0.18); ell(g, x + s * 18, y - 49, 5, 25, '#ff9ff3', s * 0.18); });
      ell(g, x, y, 36, 34, '#f1f2f6');
      if (front) { ell(g, x, y + 14, 15, 11, '#fff'); g.fillStyle = '#fff'; g.strokeStyle = '#999'; g.fillRect(x - 6, y + 20, 12, 10); g.strokeRect(x - 6, y + 20, 12, 10); }
    }
    if (front) {
      [-1, 1].forEach(s => { ell(g, x + s * 14, y - 7, 5.5, 7, '#17202a'); ell(g, x + s * 14 + 2, y - 10, 2, 2, '#fff'); });
      ell(g, x, y + 8, 8, 6, animal === 'bunny' ? '#ff6b9d' : '#17202a');
      [-1, 1].forEach(s => ell(g, x + s * 27, y + 7, 7, 5, 'rgba(255,90,120,.45)'));
      g.strokeStyle = '#4a2a1a'; g.lineWidth = 2.5; g.beginPath(); g.arc(x, y + 13, 8, 0.25, Math.PI - 0.25); g.stroke();
    }
  }

  function wheel(g, x, y, w, h) {
    box(g, x, y, w, h, 14, '#17202a');
    for (let i = 10; i < h - 6; i += 14) { g.fillStyle = '#34495e'; g.fillRect(x + 5, y + i, w - 10, 5); }
    ell(g, x + w / 2, y + h / 2, w * 0.2, w * 0.2, '#ffd32a'); ell(g, x + w / 2, y + h / 2, w * 0.08, w * 0.08, '#fff');
  }

  // Widok od tylu (w wyscigu). turn: -1, 0, 1
  function kartRear(k, turn = 0) {
    return polish(make(520, 440, g => {
      g.scale(2, 2);
      const s = turn * 9;
      head(g, k.animal, 130 + s, 83, false);
      box(g, 94 + s / 2, 108, 72, 55, 20, k.trim);               // kombinezon
      if (k.animal === 'bear') {                                  // terenowy, duze kola, klatka
        wheel(g, 6, 112, 58, 90); wheel(g, 196, 112, 58, 90);
        box(g, 52, 134, 156, 54, 12, k.body); box(g, 66, 121, 128, 24, 8, k.dark);
        g.fillStyle = k.trim; g.fillRect(52, 156, 156, 9);
        [78, 160].forEach(x => { box(g, x, 168, 22, 22, 11, '#bdc3c7'); ell(g, x + 11, 179, 6, 6, '#222'); });
      } else if (k.animal === 'dog') {                            // wyscigowy ze spojlerem
        wheel(g, 14, 135, 48, 68); wheel(g, 198, 135, 48, 68);
        poly(g, k.body, [55, 188, 76, 135, 184, 135, 205, 188]);
        g.fillStyle = '#566573'; g.fillRect(78, 112, 9, 32); g.fillRect(173, 112, 9, 32);
        box(g, 32, 107, 196, 19, 7, k.dark); g.fillStyle = k.trim; g.fillRect(122, 135, 16, 53);
        box(g, 111, 174, 38, 22, 9, '#bdc3c7'); ell(g, 130, 185, 9, 6, '#222');
      } else {                                                    // okragly z marchewkowymi wydechami
        wheel(g, 18, 128, 48, 74); wheel(g, 194, 128, 48, 74);
        ell(g, 130, 160, 82, 36, k.body); ell(g, 130, 149, 60, 17, k.dark);
        [[100, 177], [136, 177]].forEach(([x, y]) => { poly(g, '#ff7f11', [x, y, x + 24, y, x + 12, y + 30]); poly(g, '#2ecc71', [x + 4, y, x + 12, y - 15, x + 20, y]); });
        [70, 190].forEach(x => ell(g, x, 160, 9, 9, k.trim));
      }
    }), 6, true);
  }

  // Widok od przodu (ekran wyboru)
  function kartFront(k) {
    return polish(make(520, 440, g => {
      g.scale(2, 2);
      head(g, k.animal, 130, 88, true);
      const big = k.animal === 'bear';
      wheel(g, 10, big ? 117 : 137, 52, big ? 85 : 66); wheel(g, 198, big ? 117 : 137, 52, big ? 85 : 66);
      if (k.animal === 'dog') { box(g, 40, 122, 180, 14, 6, k.dark); poly(g, k.body, [52, 188, 80, 133, 180, 133, 208, 188]); }
      else if (big) box(g, 52, 133, 156, 55, 12, k.body);
      else ell(g, 130, 162, 82, 34, k.body);
      g.strokeStyle = '#222'; g.lineWidth = 9; g.beginPath(); g.arc(130, 138, 22, Math.PI * 1.05, Math.PI * 1.95); g.stroke();
      box(g, 96, 152, 68, 28, 10, '#fff'); g.fillStyle = k.dark; g.font = 'bold 22px sans-serif'; g.textAlign = 'center';
      g.fillText(k.animal === 'bear' ? '1' : k.animal === 'dog' ? '2' : '3', 130, 174);
    }), 6, true);
  }

  /* ---------- Obiekty przy trasie i przeszkody ---------- */
  const rock = (c1, c2) => make(200, 130, g => { poly(g, c1, [8, 126, 28, 55, 75, 14, 132, 30, 185, 80, 194, 126]); poly(g, c2, [75, 14, 132, 30, 115, 126, 62, 70]); });
  const pine = () => make(180, 300, g => { g.fillStyle = '#6e4423'; g.fillRect(78, 240, 24, 60); [0, 1, 2].forEach(i => { const y = 20 + i * 68, w = 52 + i * 18; poly(g, '#1e6b3c', [90, y - 15, 90 + w, y + 105, 90 - w, y + 105]); poly(g, '#f4f9ff', [90, y - 15, 114, y + 28, 90, y + 18, 66, y + 28]); }); });
  const cactus = () => make(160, 260, g => { box(g, 62, 20, 36, 240, 18, '#3c8d40'); box(g, 12, 80, 30, 80, 15, '#3c8d40'); box(g, 25, 132, 55, 28, 12, '#3c8d40'); box(g, 118, 55, 30, 80, 15, '#2f7a35'); box(g, 80, 108, 55, 27, 12, '#2f7a35'); });
  const mesa = () => make(300, 280, g => { poly(g, '#a94f2b', [20, 280, 55, 40, 95, 15, 220, 25, 245, 80, 285, 280]); g.fillStyle = '#c96f3d'; [70, 140, 215].forEach(y => g.fillRect(48, y, 200, 18)); });
  const snowman = () => make(160, 220, g => { ell(g, 80, 160, 60, 56, '#fff'); ell(g, 80, 85, 42, 40, '#eef5ff'); box(g, 52, 18, 56, 36, 6, '#222'); ell(g, 66, 76, 5, 5, '#222'); ell(g, 94, 76, 5, 5, '#222'); poly(g, '#ff7f11', [78, 86, 118, 95, 78, 99]); box(g, 48, 116, 66, 14, 7, '#e74c3c'); });
  const blocks = () => make(220, 200, g => { [[8, 104, '#e74c3c', 'A'], [112, 104, '#3498db', 'B'], [60, 8, '#f1c40f', 'C']].forEach(([x, y, c, t]) => { box(g, x, y, 96, 94, 10, c); box(g, x + 12, y + 12, 72, 70, 8, '#fdf6e3'); g.fillStyle = c; g.font = 'bold 56px sans-serif'; g.textAlign = 'center'; g.fillText(t, x + 48, y + 68); }); });
  const ball = () => make(180, 180, g => { const cs = ['#e74c3c', '#fff', '#3498db', '#fff', '#f1c40f', '#fff']; cs.forEach((c, i) => { g.fillStyle = c; g.beginPath(); g.moveTo(90, 90); g.arc(90, 90, 86, i * Math.PI / 3, (i + 1) * Math.PI / 3); g.fill(); }); ell(g, 90, 90, 17, 17, '#27ae60'); });
  const rings = () => make(180, 260, g => { box(g, 80, 25, 20, 220, 10, '#c8a165'); ['#9b59b6', '#3498db', '#2ecc71', '#f1c40f', '#e74c3c'].reverse().forEach((c, i) => ell(g, 90, 230 - i * 42, 82 - i * 11, 24, c)); ell(g, 90, 26, 20, 20, '#e67e22'); });
  const mushroom = col => make(200, 220, g => { box(g, 70, 100, 60, 118, 24, '#fdf0d5'); g.fillStyle = col; g.beginPath(); g.ellipse(100, 112, 96, 94, 0, Math.PI, 0); g.fill(); [[60, 70, 17], [118, 45, 13], [148, 85, 15], [98, 90, 10]].forEach(p => ell(g, p[0], p[1], p[2], p[2], '#fff')); });
  const lolly = () => make(160, 290, g => { box(g, 74, 90, 13, 200, 6, '#fff'); ['#ff6b81', '#fff', '#ff6b81', '#fff', '#ff4757'].forEach((c, i) => ell(g, 80, 80, 74 - i * 15, 74 - i * 15, c)); });
  const lavaRock = () => make(200, 140, g => { poly(g, '#2d2323', [6, 136, 30, 62, 78, 18, 140, 28, 188, 82, 195, 136]); g.strokeStyle = '#ff6a00'; g.lineWidth = 8; g.beginPath(); g.moveTo(80, 22); g.lineTo(98, 66); g.lineTo(70, 94); g.lineTo(88, 134); g.moveTo(98, 66); g.lineTo(150, 90); g.stroke(); });
  const fire = () => make(160, 220, g => { poly(g, '#e8390e', [20, 215, 12, 130, 48, 160, 66, 40, 100, 120, 134, 70, 150, 215]); poly(g, '#ff9f1a', [40, 215, 48, 150, 70, 175, 84, 95, 110, 160, 124, 215]); poly(g, '#ffe14d', [62, 215, 82, 150, 104, 215]); });
  const deadTree = () => make(180, 260, g => { g.strokeStyle = '#1c1212'; g.lineCap = 'round'; [[90, 258, 90, 70, 24], [90, 140, 32, 75, 13], [90, 105, 148, 40, 13], [90, 75, 70, 15, 9], [45, 90, 20, 100, 7]].forEach(l => { g.lineWidth = l[4]; g.beginPath(); g.moveTo(l[0], l[1]); g.lineTo(l[2], l[3]); g.stroke(); }); });

  /* ---------- Tla (powtarzalne w poziomie) ---------- */
  const W = 1200, H = 300;
  function ridge(g, col, peaks, snow) {
    peaks.forEach(([x, h, w]) => [-W, 0, W].forEach(o => {
      poly(g, col, [x + o - w, H, x + o, H - h, x + o + w, H]);
      if (snow) poly(g, snow, [x + o, H - h, x + o + w * .3, H - h * .7, x + o + w * .1, H - h * .76, x + o - w * .08, H - h * .67, x + o - w * .3, H - h * .7]);
    }));
  }
  const bgs = {
    canyon: g => { ell(g, 880, 70, 45, 45, '#fff3b0'); [['#c87750', [[0, 190, 120], [330, 130, 160], [640, 220, 100], [930, 150, 140]]], ['#9c4a2f', [[170, 90, 110], [500, 120, 80], [790, 80, 150], [1090, 110, 70]]]].forEach(([c, a]) => a.forEach(([x, h, w]) => [-W, 0, W].forEach(o => poly(g, c, [x + o - w, H, x + o - w * .72, H - h, x + o + w * .65, H - h, x + o + w, H])))); },
    alps: g => { ridge(g, '#7f9fc4', [[60, 240, 220], [380, 200, 200], [700, 270, 240], [1000, 210, 190]], '#fff'); ridge(g, '#4d7298', [[220, 130, 200], [560, 100, 180], [880, 140, 210], [1160, 90, 140]], '#e8f2ff'); },
    room: g => {
      for (let x = 0; x < W; x += 80) { g.fillStyle = '#9fd3e8'; g.fillRect(x, 0, 40, H); }
      box(g, 90, 60, 220, 170, 6, '#fff'); box(g, 102, 72, 196, 146, 2, '#1f3a68'); ell(g, 250, 115, 26, 26, '#fff6b3'); g.fillStyle = '#fff'; g.fillRect(196, 72, 9, 146); g.fillRect(102, 142, 196, 9);
      box(g, 450, 140, 300, 14, 4, '#8d5a32'); ['#e74c3c', '#27ae60', '#f39c12', '#8e44ad', '#2980b9'].forEach((c, i) => box(g, 466 + i * 34, 70 + (i % 3) * 10, 28, 70 - (i % 3) * 10, 3, c)); ell(g, 690, 115, 26, 26, '#e67e22');
      box(g, 860, 120, 260, 180, 8, '#c0825a'); [150, 215].forEach(y => { box(g, 876, y, 228, 52, 6, '#dca578'); ell(g, 990, y + 26, 10, 10, '#6e4423'); });
    },
    fairy: g => {
      ['#ff6b6b', '#ffa94d', '#ffe066', '#8ce99a', '#74c0fc', '#b197fc'].forEach((c, i) => { g.strokeStyle = c; g.lineWidth = 15; g.beginPath(); g.arc(330, 330, 270 - i * 15, Math.PI, 0); g.stroke(); });
      [[800, 150, 60], [870, 90, 70], [955, 160, 55]].forEach(([x, y, w]) => { g.fillStyle = '#f6d6ff'; g.fillRect(x, y, w, H - y); poly(g, '#d6336c', [x - 10, y, x + w / 2, y - 70, x + w + 10, y]); box(g, x + w / 2 - 9, y + 25, 18, 30, 9, '#5f3dc4'); });
      [0, 200, 420, 640, 860, 1060, 1200].forEach((x, i) => ell(g, x, 315, 150, 60 + (i % 2) * 25, '#69c779'));
    },
    volcano: g => {
      ridge(g, '#3a2020', [[140, 110, 190], [900, 130, 220], [1150, 80, 150]]);
      [[540, 30, 45], [580, 5, 55], [630, -15, 65], [505, 62, 30]].forEach(p => ell(g, p[0], p[1] + 20, p[2], p[2] * .7, 'rgba(60,50,55,.75)'));
      poly(g, '#251414', [250, H, 475, 75, 590, 75, 820, H]); ell(g, 532, 76, 58, 12, '#ff8c00');
      [[505, 480, 450, 420], [550, 580, 610, 700]].forEach(a => poly(g, '#ff4d00', [a[0], 78, a[0] + 22, 78, a[1], 170, a[3] + 14, H, a[3] - 8, H, a[2], 170]));
    }
  };

  const SCENES = [
    { id: 'canyon', name: 'Kanion', sky: ['#2f8fff', '#ffd9a0'], grass: ['#f0a04f', '#e39243'], road: ['#8a6a55', '#836350'], rumble: ['#fff', '#c0392b'], lane: '#f5e0c3', deco: () => [mesa(), cactus(), rock('#b5623a', '#d88255')], obst: () => [rock('#6f3b28', '#955338'), cactus()], music: { tempo: 132, root: 52, scale: [0, 3, 5, 7, 10], wave: 'square' } },
    { id: 'alps', name: 'Alpy', sky: ['#1e7bf0', '#d6efff'], grass: ['#eef6ff', '#dceaf8'], road: ['#6c7a89', '#667483'], rumble: ['#fff', '#2980b9'], lane: '#fff', deco: () => [pine(), pine(), rock('#7f8c8d', '#bdc3c7')], obst: () => [snowman(), rock('#566573', '#85929e')], music: { tempo: 124, root: 55, scale: [0, 2, 4, 7, 9], wave: 'triangle' } },
    { id: 'room', name: 'Pokój dziecka', sky: ['#bde8f5', '#e8f8ff'], grass: ['#c89463', '#bb8756'], road: ['#5b6abf', '#5563b5'], rumble: ['#f1c40f', '#e74c3c'], lane: '#fff', deco: () => [blocks(), rings(), ball()], obst: () => [blocks(), ball()], music: { tempo: 116, root: 60, scale: [0, 2, 4, 5, 7, 9], wave: 'triangle' } },
    { id: 'fairy', name: 'Bajkowa kraina', sky: ['#8e7dff', '#ffd1ec'], grass: ['#68e06f', '#56d263'], road: ['#d9a7e0', '#d19ed9'], rumble: ['#fff', '#ff6b9d'], lane: '#fff7a8', deco: () => [mushroom('#e74c3c'), lolly(), mushroom('#8e44ad')], obst: () => [mushroom('#ff7f11'), lolly()], music: { tempo: 128, root: 57, scale: [0, 2, 4, 7, 9, 11], wave: 'square' } },
    { id: 'volcano', name: 'Wulkan', sky: ['#1b0b16', '#c4451c'], grass: ['#3b2a2a', '#332323'], road: ['#555059', '#4e4952'], rumble: ['#ffb000', '#d92b04'], lane: '#ffcf70', deco: () => [deadTree(), fire(), lavaRock()], obst: () => [lavaRock(), fire()], music: { tempo: 144, root: 45, scale: [0, 1, 3, 5, 7, 8], wave: 'sawtooth' } }
  ];

  const cache = {};
  function scene(i) {
    if (!cache[i]) { const s = SCENES[i]; const haze = { canyon: 'rgba(255,217,160,', alps: 'rgba(214,239,255,', room: 'rgba(232,248,255,', fairy: 'rgba(255,209,236,', volcano: 'rgba(196,69,28,' }[s.id];
      const tint = { canyon: 'rgba(255,244,225,.8)', alps: 'rgba(255,255,255,.85)', fairy: 'rgba(255,255,255,.9)', volcano: 'rgba(40,25,30,.65)' }[s.id];
      cache[i] = { ...s, haze, cloud: tint && cloud(tint), bg: make(W, H, bgs[s.id]), decoImg: s.deco().map(c => sticker(c)), obstImg: s.obst().map(c => sticker(c, 5)) }; }
    return cache[i];
  }
  function preview(i) {
    const s = scene(i);
    return make(240, 150, g => {
      const gr = g.createLinearGradient(0, 0, 0, 85); gr.addColorStop(0, s.sky[0]); gr.addColorStop(1, s.sky[1]);
      g.fillStyle = gr; g.fillRect(0, 0, 240, 85); g.drawImage(s.bg, 200, 0, 600, 300, 0, 0, 240, 85);
      g.fillStyle = s.grass[0]; g.fillRect(0, 85, 240, 65); poly(g, s.road[0], [108, 85, 132, 85, 215, 150, 25, 150]);
      g.drawImage(s.decoImg[0], 5, 70, 48, 62); g.drawImage(s.decoImg[1], 188, 70, 46, 62);
    });
  }
  return { RAINBOW, balloons, KARTS, SCENES, scene, preview, kartRear, kartFront, make };
})();
