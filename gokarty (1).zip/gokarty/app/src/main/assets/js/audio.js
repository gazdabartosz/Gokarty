'use strict';
// Muzyka i dzwieki syntezowane przez Web Audio API.
const Sound = (() => {
  let ac, master, musicBus, sfxBus, noise, engine, engineGain;
  let song = null, step = 0, nextTime = 0, timer = null;
  const opt = { music: true, sfx: true };

  function init() {
    if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ac = new AC();
    master = ac.createDynamicsCompressor(); master.connect(ac.destination);
    musicBus = ac.createGain(); sfxBus = ac.createGain(); musicBus.connect(master); sfxBus.connect(master);
    noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    apply(); timer = setInterval(schedule, 40);
  }
  function apply() { if (!ac) return; musicBus.gain.value = opt.music ? 0.55 : 0; sfxBus.gain.value = opt.sfx ? 1 : 0; }
  const freq = n => 440 * Math.pow(2, (n - 69) / 12);

  function tone(bus, f, t, dur, vol, wave, slideTo) {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = wave; o.frequency.setValueAtTime(f, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus); o.start(t); o.stop(t + dur + 0.05);
  }
  function hiss(bus, t, dur, vol, type, f, slideTo) {
    const s = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain();
    s.buffer = noise; fl.type = type; fl.frequency.setValueAtTime(f, t);
    if (slideTo) fl.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(fl); fl.connect(g); g.connect(bus); s.start(t); s.stop(t + dur);
  }

  // Prosty sekwencer: 64 szesnastki = 4 takty
  const MELODY = [0, -1, 2, -1, 4, -1, 2, 3, 4, -1, 5, 4, 2, -1, 1, -1, 0, -1, 2, 4, 5, -1, 7, -1, 6, 5, 4, -1, 2, -1, -1, -1];
  const CHORDS = [0, 5, 7, 0];
  function schedule() {
    if (!ac || !song || ac.state !== 'running') return;
    if (nextTime < ac.currentTime) nextTime = ac.currentTime + 0.05;
    const len = 60 / song.tempo / 4;
    while (nextTime < ac.currentTime + 0.2) {
      const bar = Math.floor(step / 16) % 4, s = step % 16, t = nextTime, root = song.root + CHORDS[bar];
      if (s % 2 === 0) tone(musicBus, freq(root - 12 + (s % 8 === 6 ? 7 : 0)), t, len * 1.7, 0.16, 'triangle');
      const m = MELODY[(step + (bar > 1 ? 16 : 0)) % 32];
      if (m >= 0) { const sc = song.scale; tone(musicBus, freq(song.root + 12 + sc[m % sc.length] + 12 * Math.floor(m / sc.length)), t, len * 1.8, 0.07, song.wave); }
      if (s % 8 === 0) tone(musicBus, 130, t, 0.13, 0.35, 'sine', 45);
      if (s % 8 === 4) hiss(musicBus, t, 0.12, 0.14, 'highpass', 1500);
      if (s % 2 === 1) hiss(musicBus, t, 0.035, 0.06, 'highpass', 7000);
      nextTime += len; step++;
    }
  }

  return {
    init,
    setOptions(music, sfx) { opt.music = music; opt.sfx = sfx; apply(); },
    music(s) { if (song !== s) { song = s; step = 0; nextTime = 0; } },
    menuMusic: { tempo: 112, root: 55, scale: [0, 2, 4, 7, 9], wave: 'triangle' },
    sfx(name) {
      if (!ac) return; const t = ac.currentTime, b = sfxBus;
      if (name === 'click') tone(b, 660, t, 0.08, 0.2, 'square', 990);
      if (name === 'count') tone(b, 440, t, 0.35, 0.35, 'square');
      if (name === 'go') tone(b, 880, t, 0.7, 0.35, 'square');
      if (name === 'boost') { hiss(b, t, 0.8, 0.5, 'bandpass', 400, 5000); tone(b, 220, t, 0.6, 0.2, 'sawtooth', 1200); }
      if (name === 'crash') { hiss(b, t, 0.45, 0.8, 'lowpass', 1800, 100); tone(b, 160, t, 0.35, 0.5, 'square', 40); }
      if (name === 'pop') { hiss(b, t, 0.07, 0.45, 'highpass', 2500); [84, 88, 91, 96].forEach((n, i) => tone(b, freq(n), t + i * 0.055, 0.16, 0.22, 'triangle')); }
      if (name === 'boing') { tone(b, 180, t, 0.14, 0.35, 'sine', 520); tone(b, 520, t + 0.13, 0.22, 0.25, 'sine', 300); }
      if (name === 'bump') { tone(b, 220, t, 0.18, 0.4, 'square', 90); tone(b, 520, t + 0.08, 0.18, 0.2, 'triangle', 380); }
      if (name === 'finish') [72, 76, 79, 84, 79, 84].forEach((n, i) => tone(b, freq(n), t + i * 0.14, i === 5 ? 0.8 : 0.18, 0.3, 'square'));
    },
    // Silnik: speed 0..1.5, on=false wylacza
    engine(on, speed = 0) {
      if (!ac) return;
      if (on && !engine) {
        engine = ac.createOscillator(); engineGain = ac.createGain(); const f = ac.createBiquadFilter();
        engine.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 600; engineGain.gain.value = 0;
        engine.connect(f); f.connect(engineGain); engineGain.connect(sfxBus); engine.start();
      }
      if (engine) {
        if (on) { engine.frequency.setTargetAtTime(45 + speed * 95, ac.currentTime, 0.06); engineGain.gain.setTargetAtTime(0.09, ac.currentTime, 0.1); }
        else { engine.stop(); engine.disconnect(); engine = null; }
      }
    },
    suspend() { if (ac) ac.suspend(); },
    resume() { if (ac) ac.resume(); }
  };
})();
