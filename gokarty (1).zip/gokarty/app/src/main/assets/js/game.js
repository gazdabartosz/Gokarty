'use strict';
// Silnik wyscigu: pseudo-3D (droga z segmentow), kamera za gokartem.
const Game = (() => {
  const SEG = 200, ROAD = 1500, CAM_H = 1100, DEPTH = 0.84, DRAW = 160;
  const PLAYER_Z = CAM_H * DEPTH / 0.86;
  const MAX = 9000;            // predkosc bazowa (jednostki/s)
  const KART_W = 510;          // szerokosc gokarta w swiecie
  const BOOST_MULT = 1.5, BOOST_TIME = 3, BOOST_LEN = 12;
  const LANES = [-0.64, 0, 0.64];
  // Indeksy 0-2 jak w wersji 1.0 (zapisane wyniki), piaskownica dopisana na koncu.
  const DIFF = [
    { name: 'Łatwy', ai: [0.82, 0.93], gap: 60, curve: 2.5, double: 0, mult: 1, speed: 1, drift: 0.22 },
    { name: 'Średni', ai: [0.93, 1.04], gap: 42, curve: 3.8, double: 0.2, mult: 1.5, speed: 1, drift: 0.22 },
    { name: 'Trudny', ai: [1.01, 1.12], gap: 30, curve: 5, double: 0.4, mult: 2, speed: 1, drift: 0.22 },
    { name: 'Piaskownica', ai: [0.62, 0.84], gap: 80, curve: 1.2, double: 0, mult: 0.5, speed: 0.65, drift: 0, kid: true }
  ];
  const OBST = [
    { name: 'Brak', gap: 0, mult: 0.8 }, { name: 'Mało', gap: 2.2, mult: 0.9 },
    { name: 'Średnio', gap: 1, mult: 1 }, { name: 'Dużo', gap: 0.55, mult: 1.2 }
  ];
  const BALLOON_PTS = 50;
  const canvas = document.getElementById('game'), g = canvas.getContext('2d');
  let W = 960, H = 540;
  let segs = [], rivals = [], scene, sprites, cfg, onFinish;
  let state = 'demo', dist = 0, speed = 0, px = 0, time = 0, count = 0, boost = 0, hurt = 0, shake = 0;
  let bgX = 0, finishDist = 0, place = 6, finishTimer = 0, lastCount = 0, clock = 0;
  const input = { left: false, right: false };

  let K = 1, parts = [], pops = [], balloons = 0, balloonImgs;
  function resize() {
    H = 540; W = Math.round(H * Math.max(1.2, innerWidth / Math.max(1, innerHeight)));
    K = Math.max(1, Math.min(1.6, innerHeight * (window.devicePixelRatio || 1) / H));   // ostrzejszy obraz
    canvas.width = Math.round(W * K); canvas.height = Math.round(H * K);
  }
  addEventListener('resize', resize); resize();

  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const ease = t => 0.5 - Math.cos(t * Math.PI) / 2;

  function buildTrack(minutes, d, ob) {
    const total = Math.round(minutes * 60 * MAX * d.speed * 0.97 / SEG);
    segs = [];
    let y = 0;
    const add = (curve, ny) => segs.push({ curve, y: ny, obst: [], deco: [], balloon: null, boost: null });
    for (let i = 0; i < 50; i++) add(0, 0);
    while (segs.length < total + 20) {
      const n = Math.floor(rand(50, 130)), c = Math.random() < 0.3 ? 0 : rand(1, d.curve) * (Math.random() < 0.5 ? -1 : 1);
      const hill = Math.random() < 0.5 ? 0 : rand(-1800, 1800) * (d.kid ? 0.35 : 1), y0 = y;
      y = Math.max(-3000, Math.min(3000, y + hill));
      for (let i = 0; i < n; i++) {
        const t = i / n, bend = t < 0.25 ? ease(t * 4) : t > 0.75 ? ease((1 - t) * 4) : 1;
        add(c * bend, y0 + (y - y0) * ease((i + 1) / n));
      }
    }
    for (let i = 0; i < DRAW + 60; i++) add(0, y);
    finishDist = total * SEG;

    // dekoracje
    for (let i = 4; i < segs.length; i += 5) [-1, 1].forEach(s => {
      if (Math.random() < 0.75) segs[i].deco.push({ img: Math.floor(Math.random() * 3), x: s * rand(1.55, 3.6), w: rand(650, 1100) });
    });
    // przeszkody (nigdy nie blokuja wszystkich torow)
    for (let i = 130; ob.gap && i < total - 40; i += Math.floor(Math.max(24, d.gap * ob.gap * rand(0.75, 1.4)))) {
      const lanes = LANES.slice().sort(() => Math.random() - 0.5);
      const n = Math.random() < d.double * Math.min(1.2, 1 / ob.gap) ? 2 : 1;
      for (let k = 0; k < n; k++) segs[i].obst.push({ img: Math.floor(Math.random() * 2), x: lanes[k] + rand(-0.05, 0.05), w: 430 });
    }
    // strzalki przyspieszajace
    for (let i = 90; i < total - 80; i += Math.floor(rand(340, 520))) {
      const x = pick(LANES);
      for (let k = -14; k < BOOST_LEN + 14; k++) segs[i + k].obst = segs[i + k].obst.filter(o => Math.abs(o.x - x) > 0.35);
      for (let k = 0; k < BOOST_LEN; k++) segs[i + k].boost = { x, k };
    }
    // baloniki: pojedyncze lub po trzy, z dala od przeszkod
    for (let i = 70; i < total - 30; i += Math.floor(d.kid ? rand(30, 55) : rand(55, 110))) {
      const x = pick(LANES), n = Math.random() < 0.35 ? 3 : 1;
      for (let k = 0; k < n; k++) {
        const j = i + k * 7;
        let free = true;
        for (let q = -8; q <= 8; q++) if (segs[j + q].obst.some(o => Math.abs(o.x - x) < 0.35)) free = false;
        if (free) segs[j].balloon = { x, got: false, phase: Math.floor(Math.random() * 8) };
      }
    }
  }

  function start(config, finishCb) {
    cfg = config; onFinish = finishCb;
    const d = DIFF[cfg.diff];
    scene = Art.scene(cfg.scene);
    buildTrack(cfg.minutes, d, OBST[cfg.obst]);
    balloonImgs = balloonImgs || Art.balloons();
    parts = []; pops = []; balloons = 0;
    sprites = Art.KARTS.map(k => [-1, 0, 1].map(t => Art.kartRear(k, t)));
    const colors = ['#27ae60', '#f39c12', '#8e44ad', '#16a085', '#d35400'];
    const aiImgs = colors.map((c, i) => Art.kartRear({ ...Art.KARTS[(cfg.kart + 1 + i) % 3], body: c, dark: '#2c3e50' }));
    const speeds = colors.map((_, i) => d.ai[0] + (d.ai[1] - d.ai[0]) * i / 4).sort(() => Math.random() - 0.5);
    rivals = colors.map((_, i) => {
      const x = [-0.64, 0.64, 0, -0.64, 0.64][i];
      return { d: PLAYER_Z + 380 + i * 330, x, tx: x, base: speeds[i] * d.speed, v: 0, img: aiImgs[i], done: false, slow: 0 };
    });
    dist = 0; speed = 0; px = 0; time = 0; boost = 0; hurt = 0; shake = 0; bgX = 0; place = 6;
    state = 'count'; count = 3.999; lastCount = 4; input.left = input.right = false;
  }

  function demo(sceneIdx) {
    if (state === 'demo' && scene && scene.id === Art.SCENES[sceneIdx].id) return;
    scene = Art.scene(sceneIdx); buildTrack(1, DIFF[0], OBST[0]); parts = []; pops = [];
    segs.forEach(s => { s.balloon = null; }); rivals = []; dist = 0; px = 0; speed = 0; boost = 0; shake = 0; state = 'demo';
    Sound.engine(false);
  }

  function update(dt) {
    clock += dt;
    updateFx(dt);
    if (state === 'demo') { dist = (dist + MAX * 0.4 * dt) % (finishDist - 1000); bgX += segs[Math.floor(dist / SEG)].curve * dt * 12; return; }
    if (state === 'count') {
      count -= dt;
      const n = Math.floor(count);
      if (n < lastCount) { lastCount = n; Sound.sfx(n > 0 ? 'count' : 'go'); }
      Sound.engine(true, 0.1);
      if (count < 1) { state = 'race'; count = 0.999; }
      return;
    }
    if (count > 0) count -= dt;      // napis START!
    const d = DIFF[cfg.diff], finished = state === 'finished' || state === 'done';
    if (!finished) time += dt;
    boost = Math.max(0, boost - dt); hurt = Math.max(0, hurt - dt); shake = Math.max(0, shake - dt);

    const off = Math.abs(px) > 1.08, top = MAX * d.speed;
    const target = finished ? 0 : off ? top * 0.5 : top * (boost > 0 ? BOOST_MULT : 1);
    const rate = target > speed ? (boost > 0 ? MAX * 1.8 : MAX * 0.45) : MAX * (off ? 1.4 : 0.7);
    speed += Math.sign(target - speed) * Math.min(Math.abs(target - speed), rate * dt);

    const sp = speed / MAX, cur = segs[Math.floor((dist + PLAYER_Z) / SEG)].curve;
    const dir = finished ? 0 : (input.right ? 1 : 0) - (input.left ? 1 : 0);
    px += dir * 2.1 * dt * Math.min(1, sp * 1.5);
    px -= cur * sp * sp * d.drift * dt;
    const edge = d.kid ? 0.82 : 1.4;                 // w piaskownicy nie da sie wypasc z drogi
    px = Math.max(-edge, Math.min(edge, px));

    const old = dist; dist += speed * dt; bgX += cur * sp * dt * 30;

    if (!finished) {
      // segmenty miniete w tej klatce
      for (let i = Math.floor((old + PLAYER_Z) / SEG) + 1; i <= Math.floor((dist + PLAYER_Z) / SEG); i++) {
        const s = segs[i];
        const hit = s.obst.findIndex(o => Math.abs(o.x - px) < 0.27);
        if (hit >= 0 && d.kid) {                     // lagodnie: przeszkoda znika w chmurce
          s.obst.splice(hit, 1); speed *= 0.85; Sound.sfx('boing'); burst(W / 2, H * 0.75, ['#fff', '#dfe6e9'], 22);
        } else if (hit >= 0 && hurt <= 0) {
          speed *= 0.3; boost = 0; hurt = 1.2; shake = 0.4; Sound.sfx('crash'); burst(W / 2, H * 0.75, ['#ffb142', '#ff5252', '#fff'], 18);
        }
        const b = s.balloon;
        if (b && !b.got && Math.abs(b.x - px) < (d.kid ? 0.42 : 0.3)) {
          b.got = true; balloons++; Sound.sfx('pop');
          const bx = W / 2 + (b.x - px) * 300;
          burst(bx, H * 0.6, Art.RAINBOW, 26); pops.push({ x: bx, y: H * 0.55, t: 1 });
        }
        if (s.boost && Math.abs(s.boost.x - px) < 0.34) {
          if (boost < BOOST_TIME - 0.8) Sound.sfx('boost');
          boost = BOOST_TIME;
        }
      }
    }

    rivals.forEach((r, idx) => {
      const gap = r.d - (dist + PLAYER_Z);
      let f = r.base * (gap > 3500 ? 0.95 : gap < -3500 ? 1.05 : 1);
      if (d.kid && gap > 1500) f *= 0.75;              // rywale czekaja na malucha   // wyrownywanie stawki
      r.slow = Math.max(0, r.slow - dt); if (r.slow > 0) f *= 0.65;
      r.v += Math.sign(MAX * f - r.v) * Math.min(Math.abs(MAX * f - r.v), MAX * 0.46 * dt);
      r.d += r.v * dt;
      // omijanie przeszkod
      const i = Math.floor(r.d / SEG);
      const blocked = x => { for (let k = 1; k < 22; k++) if (segs[i + k] && segs[i + k].obst.some(o => Math.abs(o.x - x) < 0.35)) return true; return false; };
      if (blocked(r.tx)) { const free = LANES.filter(l => !blocked(l)); if (free.length) r.tx = free.sort((a, b) => Math.abs(a - r.x) - Math.abs(b - r.x))[0]; }
      else if (Math.random() < dt * 0.15) { const l = pick(LANES); if (!blocked(l)) r.tx = l; }
      // wyprzedzanie siebie nawzajem
      if (rivals.some((q, j) => j !== idx && q.d > r.d && q.d - r.d < 600 && Math.abs(q.x - r.x) < 0.3)) { const l = pick(LANES); if (!blocked(l)) r.tx = l; }
      r.x += Math.sign(r.tx - r.x) * Math.min(Math.abs(r.tx - r.x), 1.3 * dt);
      if (!r.done && r.d >= finishDist) r.done = true;
      if (r.d > finishDist + SEG * 60) r.d = finishDist + SEG * 60;

      // zderzenia z graczem
      const dz = r.d - (dist + PLAYER_Z), dx = r.x - px;
      if (!finished && Math.abs(dz) < 260 && Math.abs(dx) < 0.31) {
        if (d.kid) { r.x += dx > 0 ? 0.2 : -0.2; r.tx = dx > 0 ? 0.64 : -0.64; r.d += 90; r.slow = 0.6; }
        else if (dz > 0) { speed = Math.min(speed, r.v * 0.8); dist = r.d - PLAYER_Z - 265; }
        else { r.slow = 0.7; r.v = Math.min(r.v, speed * 0.8); r.d = dist + PLAYER_Z - 265; }
        px += dx > 0 ? -0.1 : 0.1;
        if (hurt <= 0) { Sound.sfx(d.kid ? 'boing' : 'bump'); hurt = 0.5; shake = d.kid ? 0 : 0.15; }
      }
    });

    if (!finished) {
      const me = dist + PLAYER_Z;
      place = 1 + rivals.filter(r => r.done || r.d > me).length;
      Sound.engine(true, sp);
      if (me >= finishDist) {
        place = 1 + rivals.filter(r => r.done).length;
        state = 'finished'; finishTimer = 2.2; boost = 0; Sound.engine(false); Sound.sfx('finish'); confetti();
      }
    } else if (state === 'finished' && (finishTimer -= dt) <= 0) {
      state = 'done';
      const par = cfg.minutes * 60;
      const placePts = [1000, 700, 500, 300, 200, 100][place - 1];
      const timePts = Math.max(0, Math.round((1.5 - time / par) * 2000));
      const balloonPts = balloons * BALLOON_PTS;
      const racePts = Math.round((placePts + timePts) * cfg.minutes * d.mult * OBST[cfg.obst].mult);
      onFinish({ place, time, balloons, balloonPts, racePts, points: racePts + balloonPts });
    }
  }

  /* ---------- Efekty ---------- */
  function burst(x, y, colors, n) {
    for (let i = 0; i < n; i++) parts.push({ x, y, vx: rand(-260, 260), vy: rand(-340, 80), t: rand(0.5, 1), r: rand(4, 9), c: pick(colors), g: 600 });
  }
  function confetti() {
    for (let i = 0; i < 160; i++) parts.push({ x: rand(0, W), y: rand(-H * 0.7, 0), vx: rand(-50, 50), vy: rand(60, 220), t: 4, r: rand(4, 8), c: pick(Art.RAINBOW), g: 40 });
  }
  function updateFx(dt) {
    parts.forEach(p => { p.t -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += p.g * dt; });
    parts = parts.filter(p => p.t > 0);
    pops.forEach(p => { p.t -= dt; p.y -= 90 * dt; }); pops = pops.filter(p => p.t > 0);
    if (state === 'race' && speed > MAX * 0.2 && parts.length < 220) {       // kurz spod kol
      const c = { canyon: '#e8b583', alps: '#ffffff', room: '#f3e3c3', fairy: '#fff3a8', volcano: '#ff9f43' }[scene.id];
      [-1, 1].forEach(s => { if (Math.random() < dt * 22) parts.push({ x: W / 2 + s * 85 + rand(-10, 10), y: H * 0.91, vx: s * rand(30, 110), vy: rand(-60, 10), t: rand(0.25, 0.5), r: rand(3, 8), c, g: 60 }); });
    }
  }
  function ambient() {                    // snieg, iskry, gwiazdki
    const a = { alps: ['#fff', 60, 1, 45], volcano: ['#ffa534', 40, -1, 55], fairy: ['#fff6a0', 28, 1, 18], room: null, canyon: null }[scene.id];
    if (!a) return;
    const [col, n, dir, v] = a;
    g.fillStyle = col;
    for (let i = 0; i < n; i++) {
      const y = (((i * 97.3 + dir * clock * (v + i % 7 * 6)) % H) + H) % H, x = (i * 163.7 + Math.sin(clock + i) * 28 + W) % W;
      g.globalAlpha = 0.45 + 0.45 * Math.sin(clock * 3 + i);
      g.beginPath(); g.arc(x, y, 1.5 + i % 3, 0, 7); g.fill();
    }
    g.globalAlpha = 1;
  }
  function drawFx() {
    parts.forEach(p => { g.globalAlpha = Math.min(1, p.t * 2); g.fillStyle = p.c; g.beginPath(); g.arc(p.x, p.y, p.r, 0, 7); g.fill(); });
    g.globalAlpha = 1;
    pops.forEach(p => text('+' + BALLOON_PTS, p.x, p.y, 40, '#fff200'));
  }

  /* ---------- Rysowanie ---------- */
  function quad(col, x1, y1, w1, x2, y2, w2) {
    g.fillStyle = col; g.beginPath(); g.moveTo(x1 - w1, y1); g.lineTo(x2 - w2, y2); g.lineTo(x2 + w2, y2); g.lineTo(x1 + w1, y1); g.fill();
  }

  function render() {
    const base = Math.floor(dist / SEG), pct = (dist % SEG) / SEG;
    const pSeg = Math.floor((dist + PLAYER_Z) / SEG), pPct = ((dist + PLAYER_Z) % SEG) / SEG;
    const yAt = i => segs[Math.max(0, i)].y;
    const camY = CAM_H + yAt(pSeg - 1) + (yAt(pSeg) - yAt(pSeg - 1)) * pPct;
    const horizon = H / 2;
    g.setTransform(K, 0, 0, K, 0, 0);
    g.save();
    if (shake > 0) g.translate(rand(-9, 9), rand(-7, 7));

    const sky = g.createLinearGradient(0, 0, 0, horizon);
    sky.addColorStop(0, scene.sky[0]); sky.addColorStop(1, scene.sky[1]);
    g.fillStyle = sky; g.fillRect(-10, -10, W + 20, H + 20);
    const bw = 1200, bx = -(((bgX % bw) + bw) % bw);
    for (let x = bx; x < W; x += bw) g.drawImage(scene.bg, x, horizon - 262, bw + 1, 300);
    if (scene.cloud) for (let i = 0; i < 5; i++) {
      const cw = 150 + i % 3 * 60, span = W + cw, x = (((i * 290 + clock * (7 + i * 2) - bgX * 0.4) % span) + span) % span - cw;
      g.drawImage(scene.cloud, x, 20 + (i * 53) % 130, cw, cw * 0.45);
    }
    g.fillStyle = scene.grass[0]; g.fillRect(-10, horizon + 36, W + 20, H);

    let x = 0, dx = -segs[base].curve * pct * 4, maxY = H + 10;
    const F = H * 0.85, list = [];
    for (let n = 0; n < DRAW; n++) {
      const i = base + n, s = segs[i]; if (!s) break;
      const z1 = n * SEG - pct * SEG, z2 = z1 + SEG;
      const x1 = x, x2 = x + dx; x += dx; dx += s.curve * 4;
      if (z1 <= 120) continue;
      const k1 = DEPTH / z1, k2 = DEPTH / z2;
      const sx1 = W / 2 + k1 * (x1 - px * ROAD) * F, sx2 = W / 2 + k2 * (x2 - px * ROAD) * F;
      const sy1 = H / 2 - k1 * (yAt(i - 1) - camY) * H / 2, sy2 = H / 2 - k2 * (s.y - camY) * H / 2;
      const w1 = k1 * ROAD * F, w2 = k2 * ROAD * F;
      list.push({ i, s, x: sx1, y: sy1, k: k1, clip: maxY });
      if (sy2 >= maxY || sy2 >= sy1) continue;
      const alt = Math.floor(i / 3) % 2;
      const bottom = Math.min(sy1, maxY);
      g.fillStyle = scene.grass[alt]; g.fillRect(-10, sy2, W + 20, bottom - sy2 + 1);
      quad(scene.rumble[alt], sx1, sy1 + 0.8, w1 * 1.13, sx2, sy2 - 0.6, w2 * 1.13);
      quad(scene.road[alt], sx1, sy1 + 0.8, w1, sx2, sy2 - 0.6, w2);
      if (alt === 0) [-0.32, 0.32].forEach(l => quad(scene.lane, sx1 + w1 * l, sy1, w1 * 0.012, sx2 + w2 * l, sy2, w2 * 0.012));
      if (s.boost) {                      // strzalka: ksztalt "V" skierowany do przodu
        const b = s.boost, f = (b.k % 4) / 4, a = 0.25 * (1 - f), c = 0.25 * (0.75 - f);
        const col = (Math.floor(clock * 8) + Math.floor(b.k / 4)) % 2 ? '#fff200' : '#ff9f1a';
        quad('rgba(20,20,60,.55)', sx1 + w1 * b.x, sy1, w1 * 0.3, sx2 + w2 * b.x, sy2, w2 * 0.3);
        [-1, 1].forEach(side => quad(col, sx1 + w1 * (b.x + side * a), sy1, w1 * 0.06, sx2 + w2 * (b.x + side * Math.max(0, c)), sy2, w2 * 0.06));
      }
      if (state !== 'demo') {             // linia startu i mety w szachownice
        const fin = finishDist / SEG, startL = Math.floor(PLAYER_Z / SEG) + 4;
        if ((i >= fin && i < fin + 4) || (i >= startL && i < startL + 2))
          for (let c = 0; c < 10; c++) quad((c + i) % 2 ? '#111' : '#fff', sx1 + w1 * (-0.9 + c * 0.2), sy1, w1 * 0.1, sx2 + w2 * (-0.9 + c * 0.2), sy2, w2 * 0.1);
      }
      maxY = sy2;
    }

    // mgielka przy horyzoncie dodaje glebi
    const hazeTop = Math.max(0, maxY - 2), haze = g.createLinearGradient(0, hazeTop, 0, hazeTop + 80);
    haze.addColorStop(0, scene.haze + '0.55)'); haze.addColorStop(1, scene.haze + '0)');
    g.fillStyle = haze; g.fillRect(-10, hazeTop, W + 20, 80);

    // obiekty od najdalszych
    for (let n = list.length - 1; n >= 0; n--) {
      const p = list[n];
      const put = (img, wx, ww, lift = 0) => {
        const w = p.k * ww * F, h = w * img.height / img.width;
        const cx = p.x + p.k * wx * ROAD * F, top = p.y - h - p.k * lift * H / 2;
        if (w < 2 || cx + w / 2 < 0 || cx - w / 2 > W) return;
        const vis = Math.min(h, p.clip - top); if (vis <= 0) return;
        g.drawImage(img, 0, 0, img.width, img.height * vis / h, cx - w / 2, top, w, vis);
      };
      p.s.deco.forEach(o => put(scene.decoImg[o.img], o.x, o.w));
      p.s.obst.forEach(o => put(scene.obstImg[o.img], o.x, o.w));
      const b = p.s.balloon;
      if (b && !b.got && p.i > pSeg - 1) put(balloonImgs[(Math.floor(clock * 10) + b.phase) % balloonImgs.length], b.x, 300 * (1 + 0.08 * Math.sin(clock * 9 + b.phase)), 80 + 60 * Math.sin(clock * 4 + b.phase));
      if (state !== 'demo' && p.i === Math.floor(finishDist / SEG)) banner(p, F);
      rivals.forEach(r => {
        if (Math.floor(r.d / SEG) !== p.i) return;
        const t = (r.d % SEG) / SEG, q = list[n + 1] || p;
        const mix = { x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, k: p.k + (q.k - p.k) * t };
        const w = mix.k * KART_W * F, h = w * r.img.height / r.img.width, cx = mix.x + mix.k * r.x * ROAD * F, top = mix.y - h * 0.94;
        const vis = Math.min(h, p.clip - top);
        if (w > 3 && w < W && vis > 0 && r.d > dist + PLAYER_Z * 0.55) g.drawImage(r.img, 0, 0, r.img.width, r.img.height * vis / h, cx - w / 2, top, w, vis);
      });
    }

    if (state !== 'demo') {
      const turn = state === 'race' ? (input.right ? 1 : 0) - (input.left ? 1 : 0) : 0;
      const w = DEPTH / PLAYER_Z * KART_W * F, h = w * 220 / 260;
      const bob = speed > 0 ? Math.sin(clock * 40) * 1.5 : 0, cy = H * 0.93 + bob;
      g.save(); g.translate(W / 2, cy); g.rotate(turn * 0.05);
      if (hurt > 0.5) g.rotate(Math.sin(clock * 30) * 0.12);
      if (boost > 0) [-0.14, 0.14].forEach(o => {
        const len = rand(35, 65); g.fillStyle = '#ff7b00'; g.beginPath(); g.ellipse(o * w, -6, 14, len / 2, 0, 0, 7); g.fill();
        g.fillStyle = '#fff27a'; g.beginPath(); g.ellipse(o * w, -10, 7, len / 3.5, 0, 0, 7); g.fill();
      });
      g.drawImage(sprites[cfg.kart][turn + 1], -w / 2, -h * 0.94, w, h);
      g.restore();
      if (boost > 0) {                      // linie predkosci
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 3;
        for (let i = 0; i < 18; i++) { const a = rand(0, 6.28), r1 = rand(0.38, 0.5) * W, r2 = r1 + rand(50, 140); g.beginPath(); g.moveTo(W / 2 + Math.cos(a) * r1, H / 2 + Math.sin(a) * r1 * 0.7); g.lineTo(W / 2 + Math.cos(a) * r2, H / 2 + Math.sin(a) * r2 * 0.7); g.stroke(); }
      }
    }
    ambient();
    g.restore();
    if (state !== 'demo' && state !== 'done') hud();
    drawFx();
  }

  function banner(p, F) {
    const w = p.k * ROAD * F * 1.15, h = p.k * 1600 * F, top = p.y - h;
    if (w < 8) return;
    g.fillStyle = '#ddd'; g.fillRect(p.x - w, top, w * 0.06, h); g.fillRect(p.x + w * 0.94, top, w * 0.06, h);
    g.fillStyle = '#c0392b'; g.fillRect(p.x - w, top, w * 2, h * 0.24);
    g.fillStyle = '#fff'; g.font = `bold ${h * 0.19}px sans-serif`; g.textAlign = 'center'; g.fillText('META', p.x, top + h * 0.19);
  }

  const fmt = t => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, '0')}`;
  function text(s, x, y, size, col = '#fff', align = 'center') {
    g.font = `bold ${size}px sans-serif`; g.textAlign = align; g.lineWidth = size / 7; g.strokeStyle = '#000'; g.lineJoin = 'round';
    g.strokeText(s, x, y); g.fillStyle = col; g.fillText(s, x, y);
  }
  function hud() {
    text(`Miejsce ${place}/6`, 24, 46, 34, '#ffd32a', 'left');
    text(fmt(time), 24, 86, 30, '#fff', 'left');
    g.drawImage(balloonImgs[Math.floor(clock * 6) % balloonImgs.length], 20, 98, 34, 51);
    text(`× ${balloons}`, 62, 134, 34, '#fff', 'left');
    const bw = W * 0.36, bx = (W - bw) / 2, prog = Math.min(1, (dist + PLAYER_Z) / finishDist);
    g.fillStyle = 'rgba(0,0,0,.5)'; g.fillRect(bx - 3, 17, bw + 6, 16);
    g.fillStyle = '#27ae60'; g.fillRect(bx, 20, bw * prog, 10);
    rivals.forEach(r => { g.fillStyle = '#fff'; g.fillRect(bx + bw * Math.min(1, r.d / finishDist) - 2, 17, 4, 16); });
    g.fillStyle = '#ffd32a'; g.beginPath(); g.arc(bx + bw * prog, 25, 11, 0, 7); g.fill();
    text('META', bx + bw + 38, 33, 20);
    text(`${Math.round(speed / MAX * 60)} km/h`, W - 24, 130, 28, boost > 0 ? '#ff9f1a' : '#fff', 'right');
    if (boost > 0) text('TURBO!', W / 2, 90, 46, '#ff9f1a');
    if (state === 'count' || state === 'race') {
      ['left', 'right'].forEach((side, i) => {
        const cx = i ? W - 80 : 80, cy = H - 80, s = i ? 1 : -1;
        g.fillStyle = input[side] ? 'rgba(255,211,42,.8)' : 'rgba(255,255,255,.3)';
        g.beginPath(); g.arc(cx, cy, 54, 0, 7); g.fill();
        g.fillStyle = '#222'; g.beginPath(); g.moveTo(cx + s * 28, cy); g.lineTo(cx - s * 16, cy - 28); g.lineTo(cx - s * 16, cy + 28); g.fill();
      });
    }
    if (state === 'count') { text(String(Math.min(3, Math.floor(count))), W / 2, H * 0.46, 150, '#ffd32a'); text('Dotykaj lewej lub prawej strony, aby skręcać', W / 2, H * 0.56, 26); }
    else if (state === 'race' && count > 0) text('START!', W / 2, H * 0.46, 110, '#2ecc71');
    if (state === 'finished' || state === 'done') text('META!', W / 2, H * 0.42, 120, '#ffd32a');
  }

  let last = 0, paused = false;
  function frame(ts) {
    const dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
    if (scene) { if (!paused) update(dt); render(); }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  return {
    DIFF, OBST, input, start, demo, fmt,
    pause(p) { paused = p; if (p) { input.left = input.right = false; Sound.engine(false); } },
    racing: () => state === 'count' || state === 'race' || state === 'finished',
    // pomocnicze do testow
    debug: () => ({ balloons, state, dist, finishDist, px, speed, boost, time, place, segs, rivals }),
    step: (dt, n) => { for (let i = 0; i < n; i++) update(dt); }
  };
})();
