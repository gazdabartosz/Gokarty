# Gokarty (Android)

Gra wyscigowa z widokiem zza gokarta. Android 7.0+ (API 24), poziomo, offline, bez uprawnien i bibliotek.

## Budowanie na GitHubie
1. Utworz puste repozytorium.
2. W rozpakowanym folderze `gokarty` (pliki musza byc w glownym katalogu repo):

       git init -b main
       git add .
       git commit -m "Gokarty 1.0"
       git remote add origin https://github.com/UZYTKOWNIK/gokarty.git
       git push -u origin main

3. Zakladka **Actions** -> **Build APK** -> po zakonczeniu pobierz artefakt **gokarty-apk**.
4. Rozpakuj, przenies `app-debug.apk` na telefon i zainstaluj (zezwol na instalacje z nieznanych zrodel).

Przy wgrywaniu przez przegladarke upewnij sie, ze trafil tez ukryty plik `.github/workflows/build.yml`
(mozna go utworzyc recznie: Add file -> Create new file).

Lokalnie: otworz folder w Android Studio lub `gradle assembleDebug` (Gradle 8.7, JDK 17, SDK 34).

## Sterowanie
Gokart jedzie sam. Przytrzymaj lewa / prawa polowe ekranu, aby skrecac. Pauza: przycisk II lub "wstecz".

## Punktacja
`(punkty za miejsce + punkty za czas) x minuty x mnoznik poziomu x mnoznik przeszkod + 50 za kazdy balonik`
- miejsce: 1000 / 700 / 500 / 300 / 200 / 100
- czas: (1,5 - czas / czas nominalny) x 2000, minimum 0
- poziom: piaskownica 0,5; latwy 1; sredni 1,5; trudny 2
- przeszkody: brak 0,8; malo 0,9; srednio 1; duzo 1,2

## Piaskownica (dla malych dzieci)
Wolniejsza jazda, lagodne zakrety, nie da sie wypasc z drogi, przeszkody znikaja po dotknieciu,
rywale czekaja, wiecej balonikow i zawsze 3 gwiazdki na mecie.

## Gdzie co zmieniac (app/src/main/assets)
- `js/game.js` - fizyka, trasa, przeciwnicy, stale na gorze pliku (DIFF, BOOST_*)
- `js/art.js`  - gokarty, scenerie, przeszkody
- `js/audio.js` - muzyka i dzwieki
- `js/ui.js`, `index.html`, `style.css` - menu, ustawienia, TOP 5

Mozna tez otworzyc `index.html` w przegladarce na PC (sterowanie strzalkami).

`app/debug.keystore` to publiczny klucz testowy - do sklepu Google Play uzyj wlasnego.
