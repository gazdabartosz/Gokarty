'use strict';
// Menu, ustawienia, wyniki i sterowanie.
const App = (() => {
  const $ = id => document.getElementById(id);
  const load = (k, def) => { try { return JSON.parse(localStorage.getItem(k)) ?? def; } catch (e) { return def; } };
  const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* brak pamieci */ } };

  const cfg = Object.assign({ minutes: 2, diff: 1, music: true, sfx: true, scene: 0, kart: 0 }, load('gokarty.cfg', {}));
  let screen = 'menu', lastScore = null;

  function show(name) {
    screen = name;
    document.querySelectorAll('.screen').forEach(s => s.classList.toggle('hidden', s.id !== name));
    $('btnPause').classList.toggle('hidden', name !== null);
    if (name === 'scores') drawScores();
    if (['menu', 'scenery', 'kart', 'settings', 'scores'].includes(name)) { Game.pause(false); Game.demo(cfg.scene); Sound.music(Sound.menuMusic); }
  }

  function startRace() {
    save('gokarty.cfg', cfg); show(null); Game.pause(false);
    Sound.music(Art.SCENES[cfg.scene].music);
    Game.start({ ...cfg }, finished);
  }

  function finished(r) {
    const scores = load('gokarty.top', []);
    lastScore = { points: r.points, place: r.place, time: r.time, minutes: cfg.minutes, diff: cfg.diff, scene: cfg.scene, kart: cfg.kart, id: Date.now() };
    scores.push(lastScore); scores.sort((a, b) => b.points - a.points);
    const top = scores.slice(0, 5); save('gokarty.top', top);
    const rank = top.indexOf(lastScore) + 1;
    $('resTitle').textContent = r.place === 1 ? 'Wygrana!' : 'Meta!';
    $('resBody').innerHTML = `Miejsce: ${r.place} / 6<br>Czas: ${Game.fmt(r.time)}<br><b>${r.points} pkt</b><br>` +
      (rank ? `Nowy wynik w TOP 5: pozycja ${rank}!` : 'Tym razem poza TOP 5');
    show('result');
  }

  function drawScores() {
    const s = load('gokarty.top', []);
    if (!s.length) { $('scoreList').innerHTML = '<p style="font-size:5vh">Brak wyników. Czas na pierwszy wyścig!</p>'; return; }
    $('scoreList').innerHTML = '<table><tr><th>#</th><th>Punkty</th><th>Miejsce</th><th>Czas</th><th>Trasa</th><th>Poziom</th><th>Kierowca</th></tr>' +
      s.map((r, i) => `<tr class="${lastScore && r.id === lastScore.id ? 'new' : ''}"><td>${i + 1}</td><td>${Number(r.points)}</td><td>${Number(r.place)}</td><td>${Game.fmt(r.time)}</td>` +
        `<td>${Art.SCENES[r.scene].name}, ${Number(r.minutes)} min</td><td>${Game.DIFF[r.diff].name}</td><td>${Art.KARTS[r.kart].name}</td></tr>`).join('') + '</table>';
  }

  function cards(boxId, names, key, image) {
    names.forEach((name, i) => {
      const b = document.createElement('div'); b.className = 'card'; b.appendChild(image(i)); b.append(name);
      b.onclick = () => { cfg[key] = i; mark(); Sound.sfx('click'); if (key === 'scene') Game.demo(i); save('gokarty.cfg', cfg); };
      $(boxId).appendChild(b);
    });
    const mark = () => [...$(boxId).children].forEach((c, i) => c.classList.toggle('sel', i === cfg[key]));
    mark();
  }
  function segment(boxId, options, key) {
    const mark = () => [...$(boxId).children].forEach((c, i) => c.classList.toggle('sel', options[i][1] === cfg[key]));
    options.forEach(([label, value]) => {
      const b = document.createElement('button'); b.textContent = label;
      b.onclick = () => { cfg[key] = value; mark(); save('gokarty.cfg', cfg); Sound.setOptions(cfg.music, cfg.sfx); Sound.sfx('click'); };
      $(boxId).appendChild(b);
    });
    mark();
  }

  cards('sceneryList', Art.SCENES.map(s => s.name), 'scene', i => Art.preview(i));
  cards('kartList', Art.KARTS.map(k => k.name), 'kart', i => Art.kartFront(Art.KARTS[i]));
  segment('optLen', [1, 2, 3, 4, 5].map(n => [String(n), n]), 'minutes');
  segment('optDiff', Game.DIFF.map((d, i) => [d.name, i]), 'diff');
  segment('optMusic', [['Wł.', true], ['Wył.', false]], 'music');
  segment('optSfx', [['Wł.', true], ['Wył.', false]], 'sfx');

  Sound.setOptions(cfg.music, cfg.sfx);
  const unlock = () => Sound.init();
  addEventListener('pointerdown', unlock, true); addEventListener('keydown', unlock, true);

  document.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { Sound.sfx('click'); show(b.dataset.go); });
  $('btnStart').onclick = startRace;
  $('btnAgain').onclick = startRace;
  const pause = () => { if (screen === null && Game.racing()) { Game.pause(true); Sound.music(null); show('pause'); } };
  const resumeRace = () => { show(null); Game.pause(false); Sound.music(Art.SCENES[cfg.scene].music); };
  $('btnPause').onclick = pause;
  $('btnResume').onclick = resumeRace;
  $('btnQuit').onclick = () => show('menu');
  const exit = () => { Sound.suspend(); if (window.Android) window.Android.exit(); else window.close(); };
  $('btnExit').onclick = exit;

  // Dotyk: lewa polowa ekranu = w lewo, prawa = w prawo
  const touches = new Map(), keys = new Set(), canvas = $('game');
  function steer() {
    const t = [...touches.values()];
    Game.input.left = t.includes(-1) || keys.has('ArrowLeft');
    Game.input.right = t.includes(1) || keys.has('ArrowRight');
  }
  const side = e => e.clientX < innerWidth / 2 ? -1 : 1;
  canvas.addEventListener('pointerdown', e => { touches.set(e.pointerId, side(e)); steer(); });
  canvas.addEventListener('pointermove', e => { if (touches.has(e.pointerId)) { touches.set(e.pointerId, side(e)); steer(); } });
  ['pointerup', 'pointercancel'].forEach(n => addEventListener(n, e => { touches.delete(e.pointerId); steer(); }));
  addEventListener('keydown', e => { keys.add(e.key); steer(); if (e.key === 'Escape') back(); });
  addEventListener('keyup', e => { keys.delete(e.key); steer(); });
  addEventListener('contextmenu', e => e.preventDefault());

  // Przycisk "wstecz" w Androidzie
  function back() {
    if (screen === null) pause();
    else if (screen === 'pause') resumeRace();
    else if (screen === 'kart') show('scenery');
    else if (screen === 'menu') exit();
    else show('menu');
  }

  show('menu');
  Sound.init();
  return {
    back,
    suspend() { touches.clear(); keys.clear(); steer(); pause(); Sound.suspend(); },
    resume() { Sound.resume(); }
  };
})();
// "const" nie trafia do window, a Android sprawdza window.App
window.App = App;
